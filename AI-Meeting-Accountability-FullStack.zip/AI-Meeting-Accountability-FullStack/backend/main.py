from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import re
app=FastAPI(title="AI Meeting Accountability API")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_methods=["*"],allow_headers=["*"])
class Meeting(BaseModel): transcript:str
def owner(s):
 m=re.search(r"\b([A-Z][a-z]+)\s+(?:will|must|needs to|is responsible)",s)
 return m.group(1) if m else "Not specified"
def deadline(s):
 m=re.search(r"\b(?:by|before|on)\s+([A-Za-z0-9 ,'-]+?)(?:\.|$)",s,re.I)
 return m.group(1).strip() if m else "Not specified"
@app.get("/")
def root(): return {"message":"API is running"}
@app.post("/analyze")
def analyze(x:Meeting):
 lines=[s.strip() for s in x.transcript.splitlines() if s.strip()]
 a=[];d=[];i=[];seen=set()
 for line in lines:
  lo=line.lower()
  if any(q in lo for q in ["not decided","not been decided","pending","unresolved","not finalized","yet to decide"]): i.append(line)
  if any(q in lo for q in ["agreed","approved","decision","decided"]) and "not decided" not in lo and "not been decided" not in lo: d.append(line)
  if any(q in lo for q in ["will ","must ","needs to ","responsible for","assigned to "]):
   o=owner(line);dl=deadline(line);key=(line,o,dl)
   if key not in seen:
    a.append({"task":line,"owner":o,"deadline":dl,"status":"NEW","evidence":line});seen.add(key)
 return {"action_items":a,"decisions":d,"unresolved_issues":i}
