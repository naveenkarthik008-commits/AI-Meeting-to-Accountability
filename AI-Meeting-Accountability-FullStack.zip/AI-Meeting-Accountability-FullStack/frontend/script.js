const API="http://127.0.0.1:8000/analyze";
const demo=`Arun will complete the login page by Friday.
Priya will test the payment module by Monday.
Rahul will prepare the project presentation by tomorrow.
The team agreed to use cloud hosting for the application.
The hosting provider has not been decided yet.
The database design is still pending.`;
const $=id=>document.getElementById(id);
$("demo").onclick=()=>{$("transcript").value=demo;$("status").textContent="Demo loaded."};
$("analyze").onclick=async()=>{let t=$("transcript").value.trim();if(!t){$("status").textContent="Paste a transcript first.";return}
$("status").textContent="Analyzing...";try{let r=await fetch(API,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({transcript:t})});if(!r.ok)throw Error();render(await r.json());$("status").textContent="Analysis completed."}catch(e){$("status").textContent="Backend is not running. Start FastAPI using README.txt."}};
function render(d){$("tc").textContent=d.action_items.length;$("dc").textContent=d.decisions.length;$("ic").textContent=d.unresolved_issues.length;
let owners=[...new Set(d.action_items.map(x=>x.owner).filter(x=>x!="Not specified"))];$("oc").textContent=owners.length;
$("actions").innerHTML=d.action_items.map(x=>`<div class="item"><b>Task:</b> ${e(x.task)}<br><b>Owner:</b> ${e(x.owner)}<br><b>Deadline:</b> ${e(x.deadline)}<br><b>Evidence:</b> ${e(x.evidence)}<br><span class="badge">${e(x.status)}</span></div>`).join("")||"No action items.";
$("decisions").innerHTML=d.decisions.map(x=>`<div class="item">${e(x)}</div>`).join("")||"No decisions.";
$("issues").innerHTML=d.unresolved_issues.map(x=>`<div class="item">${e(x)}</div>`).join("")||"No issues.";
$("tracker").innerHTML=d.action_items.map(x=>`<div class="item"><b>${e(x.owner)}</b> → ${e(x.task)}<br>Deadline: ${e(x.deadline)} <span class="badge">${e(x.status)}</span></div>`).join("")||"No tracker items."}
function e(x){return String(x).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;")}