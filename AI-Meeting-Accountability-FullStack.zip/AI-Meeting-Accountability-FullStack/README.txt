RUN THE PROJECT
1. Open Command Prompt.
2. cd Desktop\AI-Meeting-Accountability-FullStack\backend
3. python -m pip install -r requirements.txt
4. python -m uvicorn main:app --reload
5. Keep that window open.
6. Open frontend/index.html in Chrome.
7. Click Load Demo → Analyze Meeting.

FRONTEND = frontend/index.html, style.css, script.js
BACKEND = backend/main.py
This MVP uses transparent rule-based extraction and no API key, so it is easy to demo. An LLM can be connected later.
